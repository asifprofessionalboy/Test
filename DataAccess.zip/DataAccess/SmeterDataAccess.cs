﻿using System.Data;
using Dapper;
using Microsoft.Data.SqlClient;
using SmeterReceiver.Classes.DBModel;

namespace SmeterReceiver.DataAccess
{
    public class SmeterDataAccess : ISmeterDataAccess
    {
        private readonly IConfiguration _configuration;

        public SmeterDataAccess(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public async Task<bool> SubmitSmeterAsync(List<SmeterDBModel> smeters)
        {
            IDbConnection dbConnection = new SqlConnection(_configuration.GetConnectionString("dbcs"));
            if (smeters!=null)
            {
                var Count = await dbConnection.ExecuteAsync(@"Insert Into tb_mdm_notificationinfo(
[sumoid],
[notificationtype],
[alarmcode],
[notificationdate],
[replyserviceid],
[supplytype],
[servicepointno],
[meterno],
[paymentcardid],
[jobid],
[jobstatus],
[joberrorcode],
[devicetime],
[mseid],
[msetransid],
[eventcode],
[severity],
[transactionid],
[issuedate],
[transferstatus],
[rejectionreason],
[transfertime]
)values(
@sumoid,
@notificationtype,
@alarmcode,
@notificationdate,
@replyserviceid,
@supplytype,
@servicepointno,
@meterno,
@paymentcardid,
@jobid,
@jobstatus,
@joberrorcode,
@devicetime,
@mseid,
@msetransid,
@eventcode,
@severity,
@transactionid,
@issuedate,
@transferstatus,
@rejectionreason,
@transfertime)", smeters);
                Console.WriteLine(Count);
            }
            return true;
        }
    }
}
