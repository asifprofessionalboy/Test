﻿namespace SmeterReceiver.Classes.DBModel
{
    public interface ISmeterDataAccess
    {
        Task<bool> SubmitSmeterAsync(List<SmeterDBModel> smeters);
    }
}
