﻿//using System.Net;

//namespace SmeterReceiver.Middleware
//{
//    public class SharedSecretAuthorizationMiddleware
//    {
//        private readonly RequestDelegate _next;
//        private readonly IConfiguration _configuration;

//        public SharedSecretAuthorizationMiddleware(RequestDelegate next,IConfiguration configuration)
//        {
//            _next = next;
//            _configuration = configuration;
//        }

//        public async Task InvokeAsync(HttpContext context)
//        {
//            try
//            {
//                string val = context.Request.Headers["AuthSecret"];
//                if (val == null || !ValidateSharedSecret(val))
//                {
//                    context.Response.StatusCode = (int)HttpStatusCode.Unauthorized;
//                    context.Response.ContentType = "text/html";
//                    await context.Response.WriteAsync("Auth Secret not sent or Invalid Auth Secret");
//                    return;
//                }
//                await _next(context);
//            }
//            catch (Exception ex)
//            {
//                context.Response.StatusCode = (int)HttpStatusCode.InternalServerError;
//                context.Response.ContentType = "text/html";
//                await context.Response.WriteAsync(ex.Message);
//            }

//        }
//        private bool ValidateSharedSecret(string headerVal)
//        {
//            return _configuration.GetValue<string>("SharedSecret") == headerVal;
//        }
//    }
//}
