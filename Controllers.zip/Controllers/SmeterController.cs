﻿using System.Net;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using SmeterReceiver.Classes.DBModel;
using SmeterReceiver.Classes.DTO;

namespace SmeterReceiver.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SmeterController : ControllerBase
    {
        private readonly IConfiguration _configuration;
        private readonly ISmeterDataAccess _smeterDataAccess;
        private readonly ILogger<SmeterController> _logger;

        public SmeterController(IConfiguration configuration, ISmeterDataAccess smeterDataAccess, ILogger<SmeterController> logger)
        {
            _configuration = configuration;
            _smeterDataAccess = smeterDataAccess;
            _logger = logger;
        }

        [HttpPost]
        [Route("Submit")]
        [Authorize]
        public async Task<HttpStatusCode> Submit([FromBody] SmeterDTO SmeterDTO)
        {
            try
            {
                    SmeterDBModel dBModel = new SmeterDBModel()
                    {
                        Sumoid = SmeterDTO.Sumoid,
                        Notificationtype = SmeterDTO.Notificationtype,
                        Alarmcode = SmeterDTO.Alarmcode,
                        Notificationdate = SmeterDTO.Notificationdate ?? DateTime.Now,
                        Replyserviceid = SmeterDTO.Replyserviceid,
                        Supplytype = SmeterDTO.Supplytype,
                        Servicepointno = SmeterDTO.Servicepointno,
                        Meterno = SmeterDTO.Meterno,
                        Paymentcardid = SmeterDTO.Paymentcardid,
                        Jobid = SmeterDTO.Jobid,
                        Jobstatus = SmeterDTO.Jobstatus,
                        Joberrorcode = SmeterDTO.Joberrorcode,
                        Devicetime = SmeterDTO.Devicetime ?? DateTime.Now,
                        Mseid = SmeterDTO.Mseid,
                        Msetransid = SmeterDTO.Msetransid,
                        Eventcode = SmeterDTO.Eventcode,
                        Severity = SmeterDTO.Severity,
                        Transactionid = SmeterDTO.Transactionid,
                        Issuedate = SmeterDTO.Issuedate ?? DateTime.Now,
                        Transferstatus = SmeterDTO.Transferstatus,
                        Rejectionreason = SmeterDTO.Rejectionreason,
                        Transfertime = SmeterDTO.Transfertime ?? DateTime.Now,
                    };
                  
                
                _logger.LogInformation("//Start submitting date");
                if (await _smeterDataAccess.SubmitSmeterAsync(new List<SmeterDBModel> { dBModel}))
                    return HttpStatusCode.OK;
                else
                    throw new BadHttpRequestException("Unable to submit data");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, ex.Message);
                throw new BadHttpRequestException("Unable to submit data." + ex.Message);
            }
            finally
            {
                _logger.LogInformation("//End submitting date");
            }
        }
    }
}
