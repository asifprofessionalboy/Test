﻿namespace SmeterReceiver.Classes.DTO
{
    public class SmeterDTO
    {
        public long? Sumoid { get; set; }
        public int? Notificationtype { get; set; }
        public int? Alarmcode { get; set; }
        public DateTime? Notificationdate { get; set; }
        public int? Replyserviceid { get; set; }
        public int? Supplytype { get; set; }
        public string? Servicepointno { get; set; }
        public string? Meterno { get; set; }
        public string? Paymentcardid { get; set; }
        public long? Jobid { get; set; }
        public int? Jobstatus { get; set; }
        public int? Joberrorcode { get; set; }
        public DateTime? Devicetime { get; set; }
        public int? Mseid { get; set; }
        public long? Msetransid { get; set; }
        public int? Eventcode { get; set; }
        public int? Severity { get; set; }
        public long? Transactionid { get; set; }
        public DateTime? Issuedate { get; set; }
        public int? Transferstatus { get; set; }
        public int? Rejectionreason { get; set; }
        public DateTime? Transfertime { get; set; }

    }
}
